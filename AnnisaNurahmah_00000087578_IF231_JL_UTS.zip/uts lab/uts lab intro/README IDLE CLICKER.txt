IDLE CLICKER

- Annisa Nurahmah (00000087578)
- Sivi Dian Pramana (00000083585)
- Shella Faulina (00000079493) 
- Willy  (00000079845)

Aturan permainan (gameplay) yang diterapkan pada aplikasi :

- Tujuan permainan: Tujuan utama permainan Idle Clicker adalah untuk menghasilkan uang atau poin sebanyak-banyaknya dengan mengklik objek "Minion" atau menggunakan Auto-Clickers untuk mengklik secara otomatis.

- Klik pada objek "Minion": Pengguna harus mengklik objek "Minion" untuk menghasilkan uang atau poin. Setiap kali objek "Minion" diklik, uang atau poin akan bertambah.

- Penggunaan uang atau poin: Uang atau poin yang diperoleh dari mengklik objek "Minion" dapat digunakan untuk membeli upgrade atau peralatan tambahan yang akan membantu pengguna menghasilkan uang lebih banyak secara otomatis, seperti Auto-Clickers atau peningkatan lainnya.

- Auto-Clickers: Auto-Clickers adalah fitur dalam permainan Idle Clicker yang dapat membantu pengguna menghasilkan uang secara otomatis tanpa harus mengklik objek "Minion" secara manual. Pengguna dapat membeli Auto-Clickers dengan menggunakan uang atau poin yang diperoleh dari mengklik objek "Minion" dan meningkatkan jumlah Auto-Clickers yang dimiliki untuk menghasilkan uang lebih cepat.

- Navigation Bar: Pada bagian awal permainan (Home page), terdapat Navigation Bar yang berisi pilihan "Main Game" dan "About Us". "Main Game" akan membawa pengguna ke layar permainan utama, sementara "About Us" akan memberikan informasi tentang pembuat atau pengembang permainan.

- Strategi bermain: Pengguna dapat mengatur strategi bermain sesuai dengan preferensi mereka, seperti memutuskan kapan harus mengklik objek "Minion" secara manual atau kapan harus menggunakan Auto-Clickers. Pengguna juga dapat memilih untuk menginvestasikan uang atau poin mereka untuk membeli upgrade atau peralatan tambahan yang paling efektif dalam menghasilkan uang lebih banyak.

- Perkembangan permainan: Seiring berjalannya permainan, pengguna akan menghadapi tantangan baru dan dapat membuka fitur atau level baru yang menghadirkan kesempatan untuk menghasilkan uang lebih banyak atau menghadapi hambatan yang lebih sulit. Pengguna harus mengelola uang atau poin mereka dengan bijaksana untuk memastikan progres permainan yang optimal.

